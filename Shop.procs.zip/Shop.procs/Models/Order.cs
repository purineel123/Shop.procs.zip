namespace ShopEase.Models;
public class Order
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public DateTime OrderDate { get; set; } = DateTime.Now;
    public decimal TotalAmount { get; set; }
    public string Status { get; set; } = "Pending";
    public string PaymentMethod { get; set; } = "Cash on Delivery";
    public User? User { get; set; }
    public ICollection<OrderDetail> Details { get; set; } = new List<OrderDetail>();
}
