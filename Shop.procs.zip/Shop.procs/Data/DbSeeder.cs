using ShopEase.Models;

namespace ShopEase.Data;

public static class DbSeeder
{
    public static void Seed(AppDbContext db)
    {
        if (!db.Users.Any())
        {
            db.Users.Add(new User
            {
                Name = "Administrator",
                Email = "admin@shopease.local",
                Password = "admin123",
                Role = "Admin"
            });
            db.Users.Add(new User
            {
                Name = "Demo Customer",
                Email = "customer@shopease.local",
                Password = "customer123",
                Role = "Customer"
            });
        }

        if (!db.Categories.Any())
        {
            db.Categories.AddRange(
                new Category { Name = "Electronics" },
                new Category { Name = "Fashion" },
                new Category { Name = "Home & Living" }
            );
            db.SaveChanges();
        }

        if (!db.Products.Any())
        {
            var electronics = db.Categories.First(c => c.Name == "Electronics");
            var fashion = db.Categories.First(c => c.Name == "Fashion");
            var home = db.Categories.First(c => c.Name == "Home & Living");

            db.Products.AddRange(
                new Product { Name = "Wireless Headphones", Description = "Comfortable Bluetooth headphones.", Price = 1499, Stock = 20, ImageUrl = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80", CategoryId = electronics.Id },
                new Product { Name = "Smart Watch", Description = "Fitness and notification smart watch.", Price = 2499, Stock = 15, ImageUrl = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80", CategoryId = electronics.Id },
                new Product { Name = "Casual Sneakers", Description = "Everyday comfortable sneakers.", Price = 1999, Stock = 25, ImageUrl = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80", CategoryId = fashion.Id },
                new Product { Name = "Backpack", Description = "Simple college and travel backpack.", Price = 899, Stock = 30, ImageUrl = "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80", CategoryId = fashion.Id },
                new Product { Name = "Table Lamp", Description = "Minimal lamp for study and bedroom.", Price = 699, Stock = 18, ImageUrl = "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80", CategoryId = home.Id },
                new Product { Name = "Coffee Mug", Description = "Ceramic mug for everyday use.", Price = 299, Stock = 50, ImageUrl = "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=800&q=80", CategoryId = home.Id }
            );
        }

        db.SaveChanges();
    }
}
