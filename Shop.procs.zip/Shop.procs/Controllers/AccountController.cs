using Microsoft.AspNetCore.Mvc;
using ShopEase.Data;
using ShopEase.Models;

namespace ShopEase.Controllers;

public class AccountController : Controller
{
    private readonly AppDbContext _db;
    public AccountController(AppDbContext db) => _db = db;

    [HttpGet] public IActionResult Login() => View();

    [HttpPost]
    public IActionResult Login(string email, string password)
    {
        var user = _db.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
        if (user == null)
        {
            ViewBag.Error = "Invalid email or password.";
            return View();
        }

        HttpContext.Session.SetInt32("UserId", user.Id);
        HttpContext.Session.SetString("UserName", user.Name);
        HttpContext.Session.SetString("Role", user.Role);
        return RedirectToAction("Index", "Home");
    }

    [HttpGet] public IActionResult Register() => View();

    [HttpPost]
    public IActionResult Register(User user)
    {
        if (_db.Users.Any(u => u.Email == user.Email))
        {
            ViewBag.Error = "Email already registered.";
            return View(user);
        }

        user.Role = "Customer";
        _db.Users.Add(user);
        _db.SaveChanges();
        return RedirectToAction("Login");
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }
}
