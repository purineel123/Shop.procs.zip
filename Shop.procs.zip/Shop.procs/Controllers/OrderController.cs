using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using ShopEase.Data;
using ShopEase.Models;

namespace ShopEase.Controllers;

public class OrderController : Controller
{
    private readonly AppDbContext _db;
    public OrderController(AppDbContext db) => _db = db;

    public IActionResult Checkout()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (!userId.HasValue) return RedirectToAction("Login", "Account");

        var cart = GetCart();
        if (!cart.Any()) return RedirectToAction("Index", "Cart");

        foreach (var item in cart)
        {
            var product = _db.Products.Find(item.ProductId);
            if (product == null || product.Stock < item.Quantity)
            {
                TempData["OrderMessage"] = $"Some cart items are no longer available in the requested quantity. Please update your cart.";
                return RedirectToAction("Index", "Cart");
            }
        }

        return View(cart);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult PlaceOrder(string paymentMethod)
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (!userId.HasValue) return RedirectToAction("Login", "Account");

        var allowedPayments = new[] { "Cash on Delivery", "UPI (Demo)", "Credit/Debit Card (Demo)" };
        if (!allowedPayments.Contains(paymentMethod))
            paymentMethod = "Cash on Delivery";

        var cart = GetCart();
        if (!cart.Any()) return RedirectToAction("Index", "Cart");

        var order = new Order
        {
            UserId = userId.Value,
            TotalAmount = cart.Sum(x => x.Total),
            Status = "Pending",
            PaymentMethod = paymentMethod
        };

        foreach (var item in cart)
        {
            var product = _db.Products.Find(item.ProductId);
            if (product == null || product.Stock < item.Quantity)
            {
                TempData["OrderMessage"] = "One or more products are out of stock. Please update your cart.";
                return RedirectToAction("Index", "Cart");
            }

            product.Stock -= item.Quantity;
            order.Details.Add(new OrderDetail
            {
                ProductId = item.ProductId,
                Quantity = item.Quantity,
                Price = item.Price
            });
        }

        _db.Orders.Add(order);
        _db.SaveChanges();
        HttpContext.Session.Remove("Cart");

        TempData["OrderSuccess"] = $"Order #{order.Id} placed successfully using {paymentMethod}.";
        return RedirectToAction("MyOrders");
    }

    public IActionResult MyOrders()
    {
        var userId = HttpContext.Session.GetInt32("UserId");
        if (!userId.HasValue) return RedirectToAction("Login", "Account");

        var orders = _db.Orders.Include(o => o.Details).ThenInclude(d => d.Product)
            .Where(o => o.UserId == userId.Value)
            .OrderByDescending(o => o.OrderDate)
            .ToList();
        return View(orders);
    }

    private List<CartItem> GetCart()
    {
        var json = HttpContext.Session.GetString("Cart");
        return string.IsNullOrEmpty(json)
            ? new List<CartItem>()
            : JsonSerializer.Deserialize<List<CartItem>>(json) ?? new List<CartItem>();
    }
}
