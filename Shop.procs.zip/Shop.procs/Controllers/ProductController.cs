using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopEase.Data;

namespace ShopEase.Controllers;

public class ProductController : Controller
{
    private readonly AppDbContext _db;
    public ProductController(AppDbContext db) => _db = db;

    public IActionResult Index(string? search, int? categoryId)
    {
        var query = _db.Products.Include(p => p.Category).AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(p => p.Name.Contains(search));
        if (categoryId.HasValue)
            query = query.Where(p => p.CategoryId == categoryId.Value);

        ViewBag.Categories = _db.Categories.ToList();
        ViewBag.Search = search;
        return View(query.ToList());
    }

    public IActionResult Details(int id)
    {
        var product = _db.Products.Include(p => p.Category).FirstOrDefault(p => p.Id == id);
        return product == null ? NotFound() : View(product);
    }
}
