using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using ShopEase.Data;
using ShopEase.Models;

namespace ShopEase.Controllers;

public class CartController : Controller
{
    private readonly AppDbContext _db;
    private const string Key = "Cart";

    public CartController(AppDbContext db) => _db = db;

    private List<CartItem> GetCart()
    {
        var json = HttpContext.Session.GetString(Key);
        return string.IsNullOrEmpty(json)
            ? new List<CartItem>()
            : JsonSerializer.Deserialize<List<CartItem>>(json) ?? new List<CartItem>();
    }

    private void SaveCart(List<CartItem> cart) =>
        HttpContext.Session.SetString(Key, JsonSerializer.Serialize(cart));

    public IActionResult Index() => View(GetCart());

    [HttpGet]
    public IActionResult Add(int id)
    {
        var product = _db.Products.Find(id);
        if (product == null) return NotFound();
        if (product.Stock <= 0)
        {
            TempData["CartMessage"] = "Sorry, this product is out of stock.";
            return RedirectToAction("Index", "Product");
        }

        var cart = GetCart();
        var item = cart.FirstOrDefault(x => x.ProductId == id);

        if (item == null)
        {
            cart.Add(new CartItem
            {
                ProductId = id,
                Name = product.Name,
                Price = product.Price,
                Quantity = 1,
                ImageUrl = product.ImageUrl
            });
        }
        else if (item.Quantity < product.Stock)
        {
            item.Quantity++;
        }
        else
        {
            TempData["CartMessage"] = $"Only {product.Stock} item(s) of {product.Name} are available.";
        }

        SaveCart(cart);
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Update(int id, int quantity)
    {
        var cart = GetCart();
        var item = cart.FirstOrDefault(x => x.ProductId == id);
        var product = _db.Products.Find(id);

        if (item != null && product != null && product.Stock > 0)
            item.Quantity = Math.Clamp(quantity, 1, product.Stock);

        SaveCart(cart);
        return RedirectToAction("Index");
    }

    public IActionResult Remove(int id)
    {
        var cart = GetCart();
        cart.RemoveAll(x => x.ProductId == id);
        SaveCart(cart);
        return RedirectToAction("Index");
    }

    public IActionResult Clear()
    {
        HttpContext.Session.Remove(Key);
        return RedirectToAction("Index");
    }
}
