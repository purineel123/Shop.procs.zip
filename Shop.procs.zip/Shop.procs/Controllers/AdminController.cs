using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShopEase.Data;
using ShopEase.Models;

namespace ShopEase.Controllers;

public class AdminController : Controller
{
    private readonly AppDbContext _db;
    public AdminController(AppDbContext db) => _db = db;

    private bool IsAdmin() => HttpContext.Session.GetString("Role") == "Admin";

    public IActionResult Index()
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        ViewBag.Products = _db.Products.Count();
        ViewBag.Users = _db.Users.Count();
        ViewBag.Orders = _db.Orders.Count();
        return View();
    }

    public IActionResult Products()
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        return View(_db.Products.Include(p => p.Category).ToList());
    }

    [HttpGet]
    public IActionResult CreateProduct()
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        ViewBag.Categories = _db.Categories.ToList();
        return View();
    }

    [HttpPost]
    public IActionResult CreateProduct(Product product)
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        _db.Products.Add(product);
        _db.SaveChanges();
        return RedirectToAction("Products");
    }

    [HttpGet]
    public IActionResult EditProduct(int id)
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        var product = _db.Products.Find(id);
        if (product == null) return NotFound();
        ViewBag.Categories = _db.Categories.ToList();
        return View(product);
    }

    [HttpPost]
    public IActionResult EditProduct(Product product)
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        var existing = _db.Products.Find(product.Id);
        if (existing == null) return NotFound();

        existing.Name = product.Name;
        existing.Description = product.Description;
        existing.Price = product.Price;
        existing.Stock = product.Stock;
        existing.ImageUrl = product.ImageUrl;
        existing.CategoryId = product.CategoryId;

        _db.SaveChanges();
        return RedirectToAction("Products");
    }

    public IActionResult DeleteProduct(int id)
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        var product = _db.Products.Find(id);
        if (product != null)
        {
            _db.Products.Remove(product);
            _db.SaveChanges();
        }
        return RedirectToAction("Products");
    }

    public IActionResult Orders()
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        return View(_db.Orders.Include(o => o.User)
            .OrderByDescending(o => o.OrderDate).ToList());
    }

    [HttpPost]
    public IActionResult UpdateOrderStatus(int id, string status)
    {
        if (!IsAdmin()) return RedirectToAction("Login", "Account");
        var order = _db.Orders.Find(id);
        if (order != null)
        {
            order.Status = status;
            _db.SaveChanges();
        }
        return RedirectToAction("Orders");
    }
}
