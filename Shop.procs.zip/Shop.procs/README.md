# ShopEase - Online Shopping Website

A college practical project converted from the supplied restaurant-booking concept into an online shopping system.

## Stack
ASP.NET Core MVC (.NET 8), C#, Entity Framework Core, SQL Server LocalDB, Bootstrap 5.

## Functional modules

### Customer
1. Register
2. Login / Logout
3. Browse products
4. Search products
5. Filter by category
6. Product details
7. Add to cart
8. Update quantity / remove item
9. Checkout
10. Place order
11. View order history

### Admin
1. Admin login
2. Dashboard
3. Add product
4. Edit product
5. Delete product
6. View products
7. View all orders
8. Update order status

## Demo accounts
Admin: admin@shopease.local / admin123
Customer: customer@shopease.local / customer123

## How to run

### Option A - Visual Studio 2022
1. Install Visual Studio 2022 with the ASP.NET and web development workload.
2. Open `ShopEase.csproj`.
3. Make sure SQL Server Express LocalDB is installed (Visual Studio normally includes it).
4. Wait for NuGet packages to restore.
5. Press F5 or Ctrl+F5.
6. The app creates `ShopEaseDb` automatically on first run.
7. If the browser does not open, use the URL shown in Visual Studio's terminal/output.

### Option B - Command Prompt / Terminal
Open a terminal in this folder and run:
    dotnet restore
    dotnet run

Then open the HTTPS/HTTP URL printed by the terminal.

## Database
The default connection string uses:
Server=(localdb)\MSSQLLocalDB;Database=ShopEaseDb;Trusted_Connection=True;TrustServerCertificate=True

No separate SQL script is required for the first run because `EnsureCreated()` creates the database and the seed method adds demo data.

## Presentation demo sequence
1. Open Home page.
2. Click Products.
3. Open a product and Add to Cart.
4. Change quantity in Cart.
5. Login as customer.
6. Checkout and Place Order.
7. Open My Orders.
8. Logout.
9. Login as admin.
10. Open Admin Dashboard.
11. Add a product.
12. Edit it.
13. Delete it.
14. Open Orders and change an order from Pending to Shipped/Delivered.
15. Payment methods are included for academic demonstration; UPI/Card are simulated and do not charge real money.

## Important academic note
This project intentionally keeps authentication simple for a practical demonstration. Passwords are stored as plain text. For a real production system, use ASP.NET Core Identity and secure password hashing.
